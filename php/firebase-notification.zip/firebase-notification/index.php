<?php
$url = "https://fcm.googleapis.com/fcm/send";
$token = "your device token";
$serverKey = 'AAAAR4FhBrA:APA91bHxE4Kku1n6vhVKi6umagrOvMFlRkqJayGsw6kSp5DRLsDZDx5FD8vJF7G3jE8lXuEZTkLtaWRj7F3Fp2QomBUJkg8CeLVlUITOqbsY25rH65HD2-QG0UVZpbnI_CIcGQ2yR880';
$title = "Notification title";
$body = "Hello I am from Your php server";
$notification = array('title' => $title, 'body' => $body, 'sound' => 'default', 'badge' => '1');
$arrayToSend = array('to' => $token, 'notification' => $notification, 'priority' => 'high');
$json = json_encode($arrayToSend);
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'Authorization: key=' . $serverKey;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
//Send the request
$response = curl_exec($ch);
//Close request
if ($response === FALSE) {
    die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);