import React from 'react'

function Dashboard() {
    return (
        <div>
            Hi, I Am Admin
        </div>
    )
}

export default Dashboard
