@extends('admin.app')

@section('content')
<style>
    body { background: #F9F9F9; }
    .myaccordion { box-shadow: 0 0 1px rgba(0,0,0,0.1); }
    .myaccordion .card-header { border-bottom-color: #EDEFF0; background: transparent; }
    .myaccordion .fa-stack { font-size: 18px; }
    .myaccordion .btn-link { width: 100%; font-weight: bold; color: #004987; padding: 0; }
    .myaccordion .btn-link:hover, .myaccordion .btn-link:focus { text-decoration: none; }
    .myaccordion li + li { margin-top: 10px; }
    .clone-template{ background: aliceblue; position:relative;}
    .remove-clone-template-row { position: absolute; top: 12px; right: 10px; background: red; color: #fff; padding: 8px; border-radius: 50%; font-size: 12px; cursor:pointer; }
</style>

    <section class="content mt-4">
	    <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-primary">
                            <h4 class="mb-2">Additional Information</hw>
                            <h5><b>Product:</b> {{ $product->product_name }}</h5>
                        </div>
                        <div class="card-body">
                            <!---->
                            <div id="accordion" class="myaccordion">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h2 class="mb-0">
                                        <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                          Benefits
                                          <span class="fa-stack fa-sm">
                                            <i class="fas fa-circle fa-stack-2x"></i>
                                            <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                                          </span>
                                        </button>
                                      </h2>
                                    </div>
                                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                      <div class="card-body">
                                        <!-- Form -->
                                            <form method="post" action="{{ route('product_benefits_store') }}" enctype="multipart/form-data" id="benefit_form">
                                                @csrf
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="heading">Heading:</label>
                                                            <input type="hidden" name="product_id" value="{{ $product->id }}" required>
                                                            <input type="text" class="form-control" placeholder="Enter heading" name="heading" id="heading" value="{{ $benefits_data->heading ?? '' }}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="center_img">Center Image <small class="text-danger">( 150 * 250 )</small></label>
                                                            <input type="file" class="form-control p-1" name="center_img" id="center_img">
                                                            @if(isset($benefits_data->center_img) && $benefits_data->center_img != '')
                                                                <img class="mt-2" src="{{ url('uploads/product/additional_info/benefits').'/'.$benefits_data->center_img }}" width="80px">
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p1">Point 1:</label>
                                                            <textarea class="form-control" placeholder="Enter point 1" name="point_1" id='p1' required>{{ $benefits_data->point_1 ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p1_img">Point 1 Image <small class="text-danger">( 120 * 120 )</small></label>
                                                            <input type="file" class="form-control p-1" name="point_1_img" id="p1_img">
                                                            @if(isset($benefits_data->point_1_img) && $benefits_data->point_1_img != '')
                                                                <img class="mt-2" src="{{ url('uploads/product/additional_info/benefits').'/'.$benefits_data->point_1_img }}" width="80px">
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p2">Point 2:</label>
                                                            <textarea class="form-control" placeholder="Enter point 2" name="point_2" id='p2' required>{{ $benefits_data->point_2 ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p2_img">Point 2 Image <small class="text-danger">( 120 * 120 )</small></label>
                                                            <input type="file" class="form-control p-1" name="point_2_img" id="p2_img">
                                                              @if(isset($benefits_data->point_2_img) && $benefits_data->point_2_img != '')
                                                                <img class="mt-2" src="{{ url('uploads/product/additional_info/benefits').'/'.$benefits_data->point_2_img }}" width="80px">
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p3">Point 3:</label>
                                                            <textarea class="form-control" placeholder="Enter point 3" name="point_3" id='p3' required>{{ $benefits_data->point_3 ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p3_img">Point 3 Image <small class="text-danger">( 120 * 120 )</small></label>
                                                            <input type="file" class="form-control p-1" name="point_3_img" id="p3_img">
                                                            @if(isset($benefits_data->point_3_img) && $benefits_data->point_3_img != '')
                                                                <img class="mt-2" src="{{ url('uploads/product/additional_info/benefits').'/'.$benefits_data->point_3_img }}" width="80px">
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p4">Point 4:</label>
                                                            <textarea class="form-control" placeholder="Enter point 4" name="point_4" id='p4' required>{{ $benefits_data->point_4 ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="p4_img">Point 4 Image <small class="text-danger">( 120 * 120 )</small></label>
                                                            <input type="file" class="form-control p-1" name="point_4_img" id="p4_img">
                                                            @if(isset($benefits_data->point_4_img) && $benefits_data->point_4_img != '')
                                                                <img class="mt-2" src="{{ url('uploads/product/additional_info/benefits').'/'.$benefits_data->point_4_img }}" width="80px">
                                                            @endif
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group text-center">
                                                            <input type="submit" value="Submit" class="btn btn-primary">                                                
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        <!-- !Form  -->
                                      </div>
                                    </div>
                                </div>
                              
                                <!-- How to use -->
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                  <h2 class="mb-0">
                                    <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                      How to use
                                      <span class="fa-stack fa-2x">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                                      </span>
                                    </button>
                                  </h2>
                                </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                  <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <form  method="post" action="{{ route('product_how_to_use_store') }}" id="how_to_use_form">
                                                @csrf
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="heading">Heading</label>
                                                            <input type="hidden" name="product_id" value="{{ $product->id }}" required>
                                                            <input type="text" class="form-control" placeholder="Enter heading" name="heading" id="heading" value="{{ $how_to_use_data->heading ?? '' }}" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="description">Description</label>
                                                            <textarea class="form-control ckeditor" placeholder="Enter description" name="description" id="description" required>{{ $how_to_use_data->description ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="form-group text-center">
                                                            <input type="submit" value="Submit" class="btn btn-primary">                                                
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                                </div>
                                <!-- !How to use -->
                                
                                <div class="card">
                                <div class="card-header" id="headingThree">
                                  <h2 class="mb-0">
                                    <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                      Frequently Asked Question
                                      <span class="fa-stack fa-2x">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                                      </span>
                                    </button>
                                  </h2>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                  <div class="card-body">
                                         <form  method="post" action="{{ route('product_faq_store') }}" id="how_faq">
                                              @csrf
                                                @if($faq_data)
                                                    @foreach($faq_data->items as $faq)
                                                        <div class="card p-4 clone-template" data-clone-template-id="{{ $loop->iteration }}">
                                                            @if($loop->index != 0)
                                                                <span class="remove-clone-template-row fa fa-trash" onclick="removeCloneTemplateRow(this)"></span>
                                                            @endif
                                                            <div class="row product-faq-row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group">
                                                                        <label for="question">Question</label>
                                                                         <input type="hidden" name="product_id" value="{{ $product->id }}" required>
                                                                        <input type="text" class="form-control question" placeholder="Enter question" name="faq[{{ $loop->iteration }}][question]" id="question" value="{{ $faq->question }}" required>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-12">
                                                                    <div class="form-group">
                                                                        <label for="answer">Answer</label>
                                                                       <textarea class="form-control answer" placeholder="Enter answer" name="faq[{{ $loop->iteration }}][answer]" id="answer" required>{{ $faq->answer }}</textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                @else
                                                    <div class="card p-4 clone-template" data-clone-template-id="1">
                                                        <div class="row product-faq-row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="question">Question</label>
                                                             <input type="hidden" name="product_id" value="{{ $product->id }}" required>
                                                            <input type="text" class="form-control question" placeholder="Enter question" name="faq[1][question]" id="question" required>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="answer">Answer</label>
                                                           <textarea class="form-control answer" placeholder="Enter answer" name="faq[1][answer]" id="answer" required></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                                    </div>
                                                @endif
                                                <div class="col-md-12 text-right">
                                                    <button type="button" class="btn btn-warning text-white" onclick="add_more()">Add More</button>
                                                </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group text-center">
                                                            <input type="submit" value="Submit" class="btn btn-primary">                                                
                                                        </div>
                                                    </div>
                                            </form>
                                  </div>
                                </div>
                              </div>
                              
                                <!-- Other -->
                                <div class="card">
                                    <div class="card-header" id="other-panel">
                                  <h2 class="mb-0">
                                    <button class="d-flex align-items-center justify-content-between btn btn-link collapsed" data-toggle="collapse" data-target="#other" aria-expanded="false" aria-controls="other">
                                      Other
                                      <span class="fa-stack fa-2x">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fas fa-plus fa-stack-1x fa-inverse"></i>
                                      </span>
                                    </button>
                                  </h2>
                                </div>
                                    <div id="other" class="collapse" aria-labelledby="other-panel" data-parent="#accordion">
                                  <div class="card-body p-4">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <form  method="post" action="{{ route('product_other') }}" id="other_info_form">
                                                @csrf
                                                <input type="hidden" name="product_id" value="{{ $product->id }}" required>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="key_ingrdients">KEY INGREDIENTS:</label>
                                                            <textarea class="form-control ckeditor" placeholder="Enter key ingrdients" name="key_ingrdients" id="key_ingrdients" required>{{ $other_data->key_ingrdients ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="manufacturer_information">MANUFACTURER INFORMATION:</label>
                                                            <textarea class="form-control ckeditor" placeholder="Enter key manufacturer_information" name="manufacturer_information" id="manufacturer_information" required>{{ $other_data->manufacturer_information ?? '' }}</textarea>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="form-group text-center">
                                                            <input type="submit" value="Submit" class="btn btn-primary">                                                
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                  </div>
                                </div>
                                </div>
                                <!-- !Other -->
                                
                            </div>
                            <!---->
                        </div>
                    </div>
                </div>
            </div>
	    </div>
    </section>

@endsection

@section('content_js')
<script>
$('#benefit_form').submit(function(){
    $(this).find(':input[type=submit]').prop('disabled', true);
});

$("#accordion").on("hide.bs.collapse show.bs.collapse", e => {
  $(e.target)
    .prev()
    .find("i:last-child")
    .toggleClass("fa-minus fa-plus");
});

// Add More

function removeCloneTemplateRow(el){
	$(el).parents('.clone-template').remove();
}


var remove_combo_btn_html = '';
var  count             =   0;
function add_more(){
    
    var faq_card_id            =   $('.clone-template').last().attr('data-clone-template-id');
    count                  =   parseInt(faq_card_id) + 1;
    
	remove_combo_btn_html	= 	'<span class="remove-clone-template-row fa fa-trash" onclick="removeCloneTemplateRow(this)"></span>';

	var combo_html = $('.clone-template').first().clone();
	combo_html.attr('data-clone-template-id', count);;
	combo_html.find('.question').attr('name', "faq["+count+"][question]").val('');
	combo_html.find('.answer').attr('name', "faq["+count+"][answer]").val('');
	combo_html.append(remove_combo_btn_html);
	$(".clone-template").last().after(combo_html);
}
// End Add More

</script>
@endsection