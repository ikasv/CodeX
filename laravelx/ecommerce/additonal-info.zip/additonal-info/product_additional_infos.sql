-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 28, 2022 at 03:55 PM
-- Server version: 10.3.34-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web4stesrv71_healiniks`
--

-- --------------------------------------------------------

--
-- Table structure for table `product_additional_infos`
--

CREATE TABLE `product_additional_infos` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `benefits` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `how_to_use` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `faq` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `other` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_additional_infos`
--

INSERT INTO `product_additional_infos` (`id`, `product_id`, `benefits`, `how_to_use`, `faq`, `other`, `updated_at`, `created_at`) VALUES
(5, 14, '{\"product_id\":\"14\",\"heading\":\"WHAT ARE THE BENEFITS OF Henna Poweder\",\"point_1\":\"Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ad, nostrum!\",\"point_2\":\"Test 2 e\",\"point_3\":\"Test 3 e\",\"point_4\":\"Test 4 e\",\"center_img\":\"166946164135.webp\",\"point_1_img\":\"166946164119.webp\",\"point_2_img\":\"166946164190.avif\",\"point_3_img\":\"166946164156.avif\",\"point_4_img\":\"166946164117.avif\"}', '{\"product_id\":\"14\",\"heading\":\"HOW TO USE OUR Henna Powder\",\"description\":\"<p><strong>Healthy moisturizer:&nbsp;<\\/strong>Apply our aloe vera gel on the skin for instant moisturization.<\\/p>\\r\\n\\r\\n<p><strong>Natural scrub:&nbsp;<\\/strong>Mix 1 tsp of our aloe vera gel with 1 tsp sugar to make a healthy body &amp; face scrub.<\\/p>\\r\\n\\r\\n<p><strong>Sunburn soother:<\\/strong>Apply our aloe vera gel on sunburnt skin for an instant soothing effect.<\\/p>\\r\\n\\r\\n<p><strong>Anti-aging protector:<\\/strong>Massage with our aloe vera gel on the face, hands &amp; neck. Let dry. Leave overnight for anti-aging treatment.<\\/p>\\r\\n\\r\\n<p><strong>Heel saver:<\\/strong>Massage your chapped heels with our aloe vera gel. Don cotton socks, and leave overnight for soft heels.<\\/p>\\r\\n\\r\\n<p><strong>Rough skin smoother:<\\/strong>Apply our aloe vera gel on rough elbows and knees for smoother skin.<\\/p>\\r\\n\\r\\n<p><strong>Hair &amp; Scalp nourisher:<\\/strong>Massage liberally on the scalp with our aloe vera gel. Leave overnight. Shampoo in the morning.<\\/p>\\r\\n\\r\\n<p><strong>Hair softener:<\\/strong>Massage on scalp &amp; hair with our aloe vera gel. Leave overnight. Shampoo in the morning.<\\/p>\\r\\n\\r\\n<p><strong>Aftershave:<\\/strong>Apply our aloe vera gel on clean shaven skin as an aftershave gel.<\\/p>\"}', '{\"product_id\":\"14\",\"items\":[{\"question\":\"What Is The Benefits of Aloe Vera Juice?\",\"answer\":\"Aloe vera juice contains many active components and can be used to treat a variety of conditions. Aloe vera has traditionally been used to treat diabetes and lower cholesterol and triglycerides. Aloe vera may have the potential to treat stomach ulcers while also keeping the skin hydrated. It also promotes hair growth.\"},{\"question\":\"Can We Drink Organic Aloe Vera Juice Daily?\",\"answer\":\"Aloe vera juice is safe to consume on a daily basis. However, drinking too much of it can result in cramping or diarrhea. This can result in an electrolyte imbalance. If you experience any of these gastrointestinal symptoms, you should drink aloe vera juice every other or third day.\"},{\"question\":\"When Should You Drink Aloe Vera Juice?\",\"answer\":\"According to health experts, aloe vera juice for drinking helps you to lose weight, improve nutrient absorption, and ease bowel function. Aloe vera juice can also help to keep your teeth healthy. Khan also discusses the health benefits of drinking this amazing juice every morning.\"}]}', '{\"product_id\":\"14\",\"key_ingrdients\":\"<p>Key Aloe vera juice contains many active components and can be used to treat a variety of conditions. Aloe vera has traditionally been used to treat diabetes and lower cholesterol and triglycerides. Aloe vera may have the potential to treat stomach ulcers while also keeping the skin hydrated. It also promotes hair growth.<\\/p>\",\"manufacturer_information\":\"<p>MANUFACTURER&nbsp; Aloe vera juice is safe to consume on a daily basis. However, drinking too much of it can result in cramping or diarrhea. This can result in an electrolyte imbalance. If you experience any of these gastrointestinal symptoms, you should drink aloe vera juice every other or third day.<\\/p>\"}', '2022-11-28 04:52:27', '2022-11-26 05:13:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product_additional_infos`
--
ALTER TABLE `product_additional_infos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product_additional_infos`
--
ALTER TABLE `product_additional_infos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
