<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductAdditionalInfo as ProductAdditionalInfoModel;

class ProductAdditionalInfo extends Controller
{
    public function __construct(Request $request)
    {
        
    }
    
    public function additional_info($id)
    {
        $product                        =   Product::where("id",$id)->first();
        $additional_info                =   ProductAdditionalInfoModel::where("product_id", $id)->first();
        $benefits_data                  =   '';
        $how_to_use_data                =   '';
        $faq_data                       =   '';
        $other_data                     =   '';
        
        if($additional_info):
            if($additional_info->benefits != ''):
                $benefits_data         =   json_decode($additional_info->benefits);
            endif;
            
            if($additional_info->how_to_use != ''):
                $how_to_use_data       =   json_decode($additional_info->how_to_use);
            endif;
            
            if($additional_info->faq != ''):
                $faq_data              =   json_decode($additional_info->faq);
            endif;
            
            if($additional_info->other != ''):
                $other_data             =   json_decode($additional_info->other);
            endif;
        endif;
        
        if (!$product) {
            return redirect("/admin");
        }
        
        return view('admin.products.additional_info', compact('product', 'benefits_data', 'how_to_use_data', 'faq_data', 'other_data'));
    }
    
    # Additional Data
    public function product_benefits_store(Request $request){
        if($request->product_id):
            $inputs['product_id']           =   $id                   =   $request->product_id;
        else:
            $id                             =   "";
        endif;
        
        $inputs['heading']              =   $request->heading;
        $inputs['point_1']              =   $request->point_1;
        $inputs['point_2']              =   $request->point_2;
        $inputs['point_3']              =   $request->point_3;
        $inputs['point_4']              =   $request->point_4;
        
        $inputs['center_img']           =   $this->uploadimage($request, "product/additional_info/benefits","center_img", $id);
        $inputs['point_1_img']          =   $this->uploadimage($request, "product/additional_info/benefits","point_1_img", $id);
        $inputs['point_2_img']          =   $this->uploadimage($request, "product/additional_info/benefits","point_2_img", $id);
        $inputs['point_3_img']          =   $this->uploadimage($request, "product/additional_info/benefits","point_3_img", $id);
        $inputs['point_4_img']          =   $this->uploadimage($request, "product/additional_info/benefits","point_4_img", $id);
        
        $result                         =   ProductAdditionalInfoModel::updateOrCreate(
                                                ['product_id'    => $request->product_id],
                                                ['benefits'     =>  json_encode($inputs)]
                                            );
            
        return back();
    }
    
    # !Additional Data
    
    # How To Use
    public function product_how_to_use_store(Request $request){
        if($request->product_id):
            $inputs['product_id']           =   $id                   =   $request->product_id;
        else:
            $id                             =   "";
        endif;
        
        $inputs['heading']              =   $request->heading;
        $inputs['description']          =   $request->description;
     
        $result                         =   ProductAdditionalInfoModel::updateOrCreate(
                                                ['product_id'    => $request->product_id],
                                                ['how_to_use'     =>  json_encode($inputs)]
                                            );
            
        return back();
    }
    
    # !How To Use
    
    # FAQ
    public function product_faq_store(Request $request){
        
        if($request->product_id):
            $inputs['product_id']           =   $id                   =   $request->product_id;
        else:
            $id                             =   "";
        endif;
        
        
        $arr                            =   array(
                                                    'product_id'                =>    $id,
                                                    'items'                     =>     $request->faq ? array_values($request->faq) : ''
                                                );
     
        $result                         =   ProductAdditionalInfoModel::updateOrCreate(
                                                ['product_id'       =>  $id],
                                                ['faq'              =>  json_encode($arr)]
                                            );
            
        return back();
    }
    
    # !FAQ
    
    # Other
    public function product_other(Request $request){
        
        if($request->product_id):
            $inputs['product_id']               =   $id                   =   $request->product_id;
        else:
            $id                                 =   "";
        endif;
        
        
        $inputs['key_ingrdients']               =   $request->key_ingrdients;
        $inputs['manufacturer_information']     =   $request->manufacturer_information;
     
       
     
        $result                             =   ProductAdditionalInfoModel::updateOrCreate(
                                                    ['product_id'   =>  $id],
                                                    ['other'        =>  json_encode($inputs)]
                                                );
            
        return back();
    }
    
    # !Other
    
    private function uploadimage($request, $folder, $file, $id = ''){
        $destinationPath = 'uploads/'.$folder;
        $imgName='';
        //if($request->hasfile('logo')) 
        if($request->hasfile($file)) 
        { 
          $file = $request->file($file);
          $extension = $file->getClientOriginalExtension();
          $filename =time().rand(10,100).'.'.$extension;
          $file->move($destinationPath, $filename);
          $imgName = $filename;
        }else{
            $additional_info                =   ProductAdditionalInfoModel::where("product_id", $id)->first();
            if($additional_info):
                if($additional_info->benefits != ''):
                    $benefits_data         =   json_decode($additional_info->benefits);
                    $imgName                =   $benefits_data->$file;
                endif;
            endif;
        }
        return $imgName;
    }
}

?>