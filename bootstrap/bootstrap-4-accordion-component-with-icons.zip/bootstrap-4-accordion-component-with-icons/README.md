# Bootstrap 4 Accordion Component With Icons

A Pen created on CodePen.io. Original URL: [https://codepen.io/tutsplus/pen/mavZGK](https://codepen.io/tutsplus/pen/mavZGK).

