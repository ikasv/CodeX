<?php
/**
 * Search & Filter Pro 
 *
 * Sample Results Template
 * 
 * @package   Search_Filter
 * @author    Ross Morsali
 * @link      https://searchandfilter.com
 * @copyright 2018 Search & Filter
 * 
 * Note: these templates are not full page templates, rather 
 * just an encaspulation of the your results loop which should
 * be inserted in to other pages by using a shortcode - think 
 * of it as a template part
 * 
 * This template is an absolute base example showing you what
 * you can do, for more customisation see the WordPress docs 
 * and using template tags - 
 * 
 * http://codex.wordpress.org/Template_Tags
 *
 */

if ( $query->have_posts() )
{
	?>
	
	
	<?php
	while ($query->have_posts())
	{
		$query->the_post();
		
		?>
<div class="centered"> 
		<?php if (has_post_thumbnail( $post->ID ) ): ?>
			<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
			<section class="cards">
				<article class="card" style="background-image: url('<?php echo $image[0]; ?>');background-size: cover;"></article>
				<b class="text-dark"><?php echo the_title();?></b>&nbsp;&nbsp;&nbsp;&nbsp;<small><?php echo the_field('product_name');?></small>
			</section>    
</div>
		<?php endif; ?>	

<style type="text/css">
section.cards {
    padding: 25px;
}
article.card {
    width: 204px;
    height: 106px;
    border-radius: 15px;

}
</style>
		
		<?php
	}
	?>

	<?php
}
else
{
	echo "No Results Found";
}

?>
