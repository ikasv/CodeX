<?php
/**
 * The dashboard-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the dashboard-specific stylesheet and JavaScript.
 *
 * @since      1.0.0
 * @author     WPALLSUPPORT <info@wpallsupport.com>
 */
class WPAS_EDD_PayU_Admin
{
    public function __construct()
    {

    }

    public function activate($network_wide = false) {
        do_action( 'wpas_payu_activate' );
    }

    public function deactivate() {
        do_action( 'wpas_payu_deactivate' );
    }

    /**
     * Register the payment gateways setting section
     *
     * @since  1.0.0
     * @param  array $gateway_sections Array of sections for the gateways tab
     * @return array                   Added PayUmoney Payments into sub-sections
     */
    public function register_gateway_section($gateway_sections){
        $gateway_sections['wpas_edd_payu'] = __( 'PayUmoney', 'wpas-edd-payu' );

        return $gateway_sections;
    }

    public function gateway_settings( $gateway_settings ) {

        $default_settings = array(
            'wpas_edd_payu' => array(
                'id'   => 'wpas_edd_payu',
                'name' => '<strong>' . __( 'PayUmoney Payments Settings', 'wpas-edd-payu' ) . '</strong>',
                'type' => 'header',
            ),
            'payu_merchant_key' => array(
                'id'   => 'payu_merchant_key',
                'name' => __( 'Merchant Key', 'wpas-edd-payu' ),
                'desc' => '',
                'type' => 'text',
                'size' => 'regular',
            ),
            'payu_salt' => array(
                'id'   => 'payu_salt',
                'name' => __( 'SALT', 'wpas-edd-payu' ),
                'desc' => '',
                'type' => 'text',
                'size' => 'regular',
            ),
        );

        $default_settings    = apply_filters( 'wpas_edd_default_payumoney_settings', $default_settings );
        $gateway_settings['wpas_edd_payu'] = $default_settings;

        return $gateway_settings;
    }
}