<?php
/*
Plugin Name: Payment Gateway for PayUmoney on Easy Digital Downloads
Plugin URL: https://wpallsupport.com
Description: A PayUmoney payment gateway addon for Easy Digital Downloads WordPress plugin
Version: 1.0.3
Author: WP ALL SUPPORT
Author URI: http://www.wpallsupport.com
Text Domain: wpas-edd-payumoney
*/

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

if ( is_admin() ) {
    if ( !function_exists( 'is_plugin_active' ) ) {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }

    if ( !is_plugin_active( 'easy-digital-downloads/easy-digital-downloads.php' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        function wpas_payu_requires_edd_plugin() {
            echo '<div class="notice notice-warning is-dismissible"><p><strong>' . sprintf( __( '%s requires to install the %sEasy Digital Downloads%s plugin.', 'wpas-edd-payumoney' ), 'Easy Digital Downloads - PayUmoney Payment Gateway', '<a href="https://wordpress.org/plugins/easy-digital-downloads/" target="_blank">', '</a>' ) . '</strong></p></div>';
        }
        add_action( 'admin_notices', 'wpas_payu_requires_edd_plugin' );
        return;
    }
}

if ( !defined( 'WPAS_EDD_PAYU_VERSION' ) ) {
    define( 'WPAS_EDD_PAYU_VERSION', '1.0.3' );
}

if ( !defined( 'WPAS_EDD_PAYU_PATH' ) ) {
    define( 'WPAS_EDD_PAYU_PATH', plugin_dir_path( __FILE__ ) );
}

if ( !defined( 'WPAS_EDD_PAYU_FILE' ) ) {
    define( 'WPAS_EDD_PAYU_FILE', __FILE__ );
}

if ( !defined( 'WPAS_EDD_PAYU_PLUGIN_URL' ) ) {
    define( 'WPAS_EDD_PAYU_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

require_once WPAS_EDD_PAYU_PATH . '/includes/class-wpas-payu.php';

function init_wpas_payu() {

    global $wpas_payu;
    $wpas_payu = WPAS_EDD_PayU::instance();

}
add_action( 'plugins_loaded', 'init_wpas_payu' );