=== Payment Gateway for PayUmoney on Easy Digital Downloads ===
Contributors: gandhirk, wpallsupport, priyank9033
Tags: online payments, payment gateway, payumoney, payuindia, easy digital downloads, indian payment gateway
Donate link: https://wpallsupport.com/
Requires at least: 4.9
Tested up to: 5.7
Stable tag: 1.0.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is a simple addon for the Easy Digital Downloads WordPress plugin to use the PayUmoney india payment gateway.

== Description ==

= PayUmoney gateway supports INR currency and this plugin is meant to be used by merchants in India. =

After checkout on the website it redirects the user to the PayUmoney payment screen where the customer can make the payment.

The plugin requires a test or live API key which can be found from the PayUmoney account settings at https://www.payumoney.com

This add on is 100% translatable.

= More plugins by WP ALL SUPPORT =

[Hide WP Admin Bar by WP ALL SUPPORT](https://wordpress.org/plugins/hide-admin-bar-by-wp-all-support/) - Hide admin bar based on user roles and conditional logic
[PayUmoney Latam](https://wordpress.org/plugins/edd-payu-latam-gateway/) - PayUmoney payment gateway for Easy Digital Downloads

= Suggestions / Feature Request =

If you have suggestions or a new feature request, feel free to get in touch with me via the contact form on our website [here](https://wpallsupport.com/contact-us/)

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/edd-payu-gateway` directory, or install the plugin through the WordPress plugins screen directly (recommended).
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Enter your API keys and choose test-mode for making test payments
4. Visit the Easy Digital Downloads payment gateway settings and select the Payment gateways you want to activate in your checkout page.
5. Select the payment icons you want to be visible on the checkout page.

== Frequently Asked Questions ==

= What Do I Need To Use The Plugin =

1.	You need to have Easy Digital Downloads plugin installed and activated on your WordPress site.
2.	You need to open a PayUmoney merchant account on [PayUmoney](https://www.payumoney.com)

= Where can I ask for help or customisation requests? =

You can submit a support ticket on our [support forum](https://wpallsupport.com/support/) at anytime.

= Does this plugin support recurring payments? =

No, PayUmoney payment gateway does not support the recurring payments for now.

= I have an idea for a great way to improve this plugin. =

Great! I’d love to hear from you at <a href="mailto:support@wpallsupport.com">support@wpallsupport.com</a>

== Screenshots ==

1. Active/deactivate the payment gateway settings.
2. PayUmoney payment gateway settings.
3. Checkout page
4. PayUmoney payment form(Can be different based on payment methods enabled)

== Changelog ==

= 1.0.3 =
* Trouble retrieving payment receipt error - FIXED

= 1.0.2 =
* Rename plugin name due to the legality of trademarks - CHANGED

= 1.0.1 =
* Translation .po files for English language - ADDED
* PHP notices while migrating on PayUmoney site - FIXED

= 1.0.0 =
* Initial release

== Upgrade Notice ==
TBA