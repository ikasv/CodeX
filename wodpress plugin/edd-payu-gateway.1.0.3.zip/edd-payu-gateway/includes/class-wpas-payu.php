<?php
/**
 * The core plugin class.
 *
 * This is used to define internationalization, dashboard-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @author     WPALLSUPPORT <info@wpallsupport.com>
 */
class WPAS_EDD_PayU {
    private static $instance = null;
    public $gateway_id      = 'wpas_edd_payu';

    /**
     * The current version of the plugin.
     *
     * @since    1.0.0
     * @access   protected
     * @var      string    $version    The current version of the plugin.
     */
    protected $version;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Define the core functionality of the plugin.
     *
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the Dashboard and
     * the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function __construct() {
        $this->setup_globals();
        $this->includes();
        $this->setup_actions();
    }

    private function setup_globals() {
        $this->version = WPAS_EDD_PAYU_VERSION;
        $this->plugin_file = WPAS_EDD_PAYU_FILE;
    }

    private function includes() {
        require_once( WPAS_EDD_PAYU_PATH . '/includes/payu-functions.php' );

        if ( !is_admin() ) {
            return;
        }

        require_once( WPAS_EDD_PAYU_PATH . '/admin/class-wpas-payu-admin.php' );
        $this->admin = new WPAS_EDD_PayU_Admin();
    }

    private function setup_actions() {

        add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
        add_action( 'edd_payment_gateways', array( $this, 'add_gateway' ) );
        add_action( 'edd_wpas_edd_payu_cc_form', '__return_false' );
        add_action( 'edd_gateway_wpas_edd_payu', array( $this, 'process_payment') );
        add_action( 'edd_enabled_payment_gateways', array( $this, 'enabled_payment_gateways') );
        add_action( 'init', array( $this, 'payu_check_callback') );

        if ( !is_admin() ) {
            return;
        }
        register_activation_hook( $this->plugin_file, array( $this->admin, 'activate' ) );
        register_deactivation_hook( $this->plugin_file, array( $this->admin, 'deactivate' ) );

        add_filter( 'edd_settings_sections_gateways', array( $this->admin, 'register_gateway_section' ) );
        add_filter( 'edd_settings_gateways', array( $this->admin, 'gateway_settings' ) );
    }

    /**
     * Retrieve the version number of the plugin.
     *
     * @since     1.0.0
     * @return    string    The version number of the plugin.
     */
    public function get_version() {
        return $this->version;
    }

    public function load_plugin_textdomain() {
        load_plugin_textdomain(
            'wpas-edd-payu',
            FALSE,
            WPAS_EDD_PAYU_PATH . '/languages/'
        );
    }

    public function add_gateway( $gateways ) {

        $default_gateway_info = array(
            $this->gateway_id => array(
                'admin_label'    => __( 'PayUmoney', 'wpas-edd-payu' ),
                'checkout_label' => __( 'PayUmoney', 'wpas-edd-payu' ),
                'supports'       => array(),
            ),
        );

        $default_gateway_info = apply_filters( 'wpas_edd_register_payu_gateway', $default_gateway_info );
        $gateways = array_merge( $gateways, $default_gateway_info );

        return $gateways;
    }

    function get_credentials()
    {
        global $edd_options;

        $account_details = array(
            'merchant_key' => isset( $edd_options['payu_merchant_key'] ) ? $edd_options['payu_merchant_key'] : '' ,
            'salt' => isset( $edd_options['payu_salt'] ) ? $edd_options['payu_salt'] :'' ,
        );

        return $account_details;
    }

    public function process_payment($purchase_data){

        if( ! wp_verify_nonce( $purchase_data['gateway_nonce'], 'edd-gateway' ) ) {
            wp_die( __( 'Nonce verification has failed', 'easy-digital-downloads' ), __( 'Error', 'easy-digital-downloads' ), array( 'response' => 403 ) );
        }

        global $edd_options;

        $account_details = $this->get_credentials();

        // Fail if no account details set
        if (!$account_details['merchant_key'] || !$account_details['salt']) {
            edd_set_error('no_credentials', __('You must enter your PayUmoney credentials in settings', 'wpas-edd-payu'));
        }

        if(edd_is_test_mode()){
            $url = 'https://sandboxsecure.payu.in/_payment';
        } else {
            $url = 'https://secure.payu.in/_payment';
        }

        // check for any stored errors
        $errors = edd_get_errors();
        if (!$errors) {

            $purchase_summary = edd_get_purchase_summary($purchase_data);
            $success_page_permalink = get_permalink($edd_options['success_page']);
            $failure_page_permalink = get_permalink($edd_options['failure_page']);

            $payment = array(
                'price' => $purchase_data['price'],
                'date' => $purchase_data['date'],
                'user_email' => $purchase_data['user_email'],
                'purchase_key' => $purchase_data['purchase_key'],
                'currency' => $edd_options['currency'],
                'downloads' => $purchase_data['downloads'],
                'cart_details' => $purchase_data['cart_details'],
                'user_info' => $purchase_data['user_info'],
                'status' => 'pending'
            );

            // record the pending payment
            $payment = edd_insert_payment($payment);

            $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20); // Unique alphanumeric Transaction ID
            edd_set_payment_transaction_id( $payment, $txnid );

            $line1 = isset($purchase_data['user_info']['address']['line1']) ? $purchase_data['user_info']['address']['line1'] : '';
            $line2 = isset($purchase_data['user_info']['address']['line2']) ? $purchase_data['user_info']['address']['line2'] : '';
            $city = isset($purchase_data['user_info']['address']['city']) ? $purchase_data['user_info']['address']['city'] : '';
            $state = isset($purchase_data['user_info']['address']['state']) ? $purchase_data['user_info']['address']['state'] : '';
            $zip = isset($purchase_data['user_info']['address']['zip']) ? $purchase_data['user_info']['address']['zip'] : '';
            $country = isset($purchase_data['user_info']['address']['country']) ? $purchase_data['user_info']['address']['country'] : '';
            $price = isset($purchase_data['price']) ? $purchase_data['price'] : '';
            $first_name = isset($purchase_data['user_info']['first_name']) ? $purchase_data['user_info']['first_name'] : '';
            $last_name = isset($purchase_data['user_info']['last_name']) ? $purchase_data['user_info']['last_name'] : '';
            $user_email = isset($purchase_data['user_email']) ? $purchase_data['user_email'] : '';
            $payment_key = get_post_meta($payment, '_edd_payment_purchase_key', true);

            $params = array(

                // Merchant details
                'key'                   => $account_details['merchant_key'],
                'surl'                  => add_query_arg( array( 'payment-confirm' => 'payu', 'edd_payu_cb'=> 1, 'payment_key' => $payment_key ), $success_page_permalink ),
                'furl'                  => add_query_arg( array( 'payment-confirm' => 'payu', 'edd_payu_cb'=> 1, 'payment_key' => $payment_key ), $failure_page_permalink ),
                'curl'                  => add_query_arg( array( 'payment-confirm' => 'payu', 'edd_payu_cb'=> 1, 'payment_key' => $payment_key ), $failure_page_permalink ),

                // Customer details
                'firstname'             => $first_name,
                'lastname'              => $last_name,
                'email'                 => $user_email,
                'address1'              => $line1,
                'address2'              => $line2,
                'city'                  => $city,
                'state'                 => $state,
                'zipcode'               => $zip,
                'country'               => $country,
                'phone'                 => '',
                'service_provider'      => 'payu_paisa',
                // Item details
                'productinfo'           => $purchase_summary,
                'amount'                => $price,
                'txnid'                 => $txnid,
                'udf1'                  => $payment,

            );

            $params = apply_filters( 'wpas_edd_payu_form_parameters', $params, $payment );

            $hash = wpas_edd_payu_hash_before_transaction($params);

            $payuform = '';

            foreach( $params as $key => $value ) {
                if( $value ) {
                    $payuform .= '<input type="hidden" name="' . $key . '" value="' . $value . '" />' . "\n";
                }
            }

            $payuform .= '<input type="hidden" name="txnid" value="' . $txnid . '" />' . "\n";
            $payuform .= '<input type="hidden" name="hash" value="' . $hash . '" />' . "\n";
            $payuform = apply_filters( 'wpas_edd_payu_form', $payuform, $payment );

            // Empty the cart
            edd_empty_cart();

            $redirect_text  = __( 'Redirecting to PayUmoney site, click on button if not redirected.', 'wpas-edd-payu' );
            $redirect_text  = apply_filters( 'wpas_edd_payu_redirect_text', $redirect_text, $payment );

            ?>
            <div class="wpas-edd-payu-form" style="padding:20px;font-family:arial,sans-serif;text-align:center;color:#555">
                <?php do_action( 'wpas_edd_payu_form_before', $payment ); ?>
                <h3><?php echo $redirect_text ;?></h3>
                <form action="<?php echo $url; ?>" name="wpas_edd_payu_form" method="POST">
                    <?php echo $payuform; ?>
                    <?php do_action( 'wpas_edd_payu_form_parameters', $payment ); ?>
                    <input type="submit" name="wpas_edd_payu_submit" value="<?php esc_attr_e( 'Go to PayUmoney', 'wpas-edd-payu' ) ;?>">
                </form>
                <script type="text/javascript">document.wpas_edd_payu_form.submit();</script>
                <?php do_action( 'wpas_edd_payu_form_after', $payment ); ?>
            </div>
        <?php
        } else {
            edd_record_gateway_error( __( 'Payment Error', 'easy-digital-downloads' ), sprintf( __( 'Payment creation failed while processing a PayUmoney payment gateway purchase. Payment data: %s', 'wpas-edd-payu' ), json_encode( $purchase_data ) ) );
            // if errors are present, send the user back to the purchase page so they can be corrected
            edd_send_back_to_checkout('?payment-mode='.$this->gateway_id);
        }

    }

    public function payu_check_callback(){
        if ( isset( $_GET[ 'edd_payu_cb' ] ) && esc_attr( $_GET[ 'edd_payu_cb' ] ) == '1' ) {
            $this->process_ipn();
        }
    }

    function process_ipn() {
        @ob_clean();

        $txn_data = array();
        if (isset($_POST)) {
            foreach($_POST as $key => $value) {
                $txn_data[$key] = htmlentities($value, ENT_QUOTES);
            }
        }

        $txnid = $txn_data['txnid'];

        $salt = edd_get_option('payu_salt');

        if(isset($txn_data['udf1'])){
            $payment_id = (int)$txn_data['udf1'];
        } else {
            $payment_id = edd_get_purchase_id_by_transaction_id($txnid);
        }

        if(wpas_edd_payu_hash_after_transaction($salt, $txn_data) && $payment_id > 0) {
            if($txn_data['status']=='success'){
                edd_update_payment_status( $payment_id, 'publish' );
                edd_insert_payment_note( $payment_id, __( 'Payment done via PayUmoney with transaction id '.$txnid, 'wpas-edd-payu' ) );
            }

            if($txn_data['status']=='pending'){
                edd_update_payment_status( $payment_id, 'pending' );
                edd_insert_payment_note( $payment_id, __( 'PayUmoney payment pending with transaction id '.$txnid, 'wpas-edd-payu' ) );
            }

            if($txn_data['status']=='failure'){
                edd_update_payment_status( $payment_id, 'failed' );
                edd_insert_payment_note( $payment_id, __( 'PayUmoney payment failed with transaction id '.$txnid, 'wpas-edd-payu' ) );
            }
        }
    }

    function enabled_payment_gateways($gateway_list){
        if(!wpas_edd_is_payu_valid_for_use()){
            unset($gateway_list['wpas_edd_payu']);
        }
        return $gateway_list;
    }
}