<?php
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

function wpas_edd_payu_hash_before_transaction($hash_data){

    $hash_sequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
    $hash_vars_seq = explode('|', $hash_sequence);
    $hash_string = '';

    foreach($hash_vars_seq as $hash_var) {
        $hash_string .= isset($hash_data[$hash_var]) ? $hash_data[$hash_var] : '';
        $hash_string .= '|';
    }

    $hash_string .= edd_get_option('payu_salt');
    $hash_data['hash'] = strtolower(hash('sha512', $hash_string));

    return $hash_data['hash'];
}

function wpas_edd_payu_hash_after_transaction($salt, $args){
    $hash_sequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
    $hash_vars_seq = explode('|', $hash_sequence);
    //generation of hash after transaction is = salt + status + reverse order of variables
    $hash_vars_seq = array_reverse($hash_vars_seq);

    $m_hash_string = $salt . '|' . $args['status'];

    foreach ($hash_vars_seq as $merc_hash_var) {
        $m_hash_string .= '|';
        $m_hash_string .= isset($args[$merc_hash_var]) ? $args[$merc_hash_var] : '';
    }

    $m_hash = strtolower(hash('sha512', $m_hash_string));

    /* The hash is valid */
    if($m_hash == $args['hash']) {
        return true;
    } else {
        return false;
    }
}

function wpas_edd_is_payu_valid_for_use() {
    return in_array( edd_get_currency(), apply_filters( 'wpas_edd_payu_supported_currencies', array( 'INR' ) ) );
}