# Paytm Donation plugin for Wordpress
* Developer Docs: https://developer.paytm.com/docs/eCommerce-plugin/wordpress
