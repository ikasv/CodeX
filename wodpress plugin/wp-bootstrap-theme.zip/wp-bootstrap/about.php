<?php get_header();?>
<?php get_template_part('template-parts/about', 'none');?>
<?php get_footer();?>
