 <!-- Footer-->
 <footer class="py-5 bg-dark">
  
<div class="container">
        <div id="footer-sidebar" class="secondary">
            <div id="footer-sidebar1">
                <?php
                if(is_active_sidebar('footer-sidebar-1')){
                    dynamic_sidebar('footer-sidebar-1');
                }
                ?>
            </div>
            
            <div id="footer-sidebar2">
                <?php
                if(is_active_sidebar('footer-sidebar-2')){
                    dynamic_sidebar('footer-sidebar-2');
                }
                ?>
            </div>

            <div id="footer-sidebar3">
                <?php
                if(is_active_sidebar('footer-sidebar-3')){
                dynamic_sidebar('footer-sidebar-3');
                }?>
            </div>
        </div>
</div>  
 <!-- <p class="m-0 text-center text-white">Copyright &copy; Your Website 2021</p></div> -->
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php bloginfo('templete_url')?>js/scripts.js"></script>
    <?php wp_footer();?>
    </body>
</html>