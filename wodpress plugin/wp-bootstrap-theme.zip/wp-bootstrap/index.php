<?php get_header();?>
<?php get_template_part('template-parts/content', 'none');?>
<?php get_footer();?>
