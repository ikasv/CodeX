 <?php

/* Start the Loop */
while (have_posts()) : the_post();



echo the_title();


echo the_excerpt();

   // get_template_part('template-parts/content', get_post_format());
endwhile; // End of the loop.




